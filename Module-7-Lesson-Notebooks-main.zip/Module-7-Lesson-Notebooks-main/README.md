Here is where we will store the coding video notebooks for each week's lesson in Module 7.
